<!-- Database Table -->
<!-- Fields - Emp_id (Foreign key to id of employees table), number_of_leaves, type of leaves, starting date, status -->