<?php
$name  = "Mukesh Bhatt";
// echo (strpos($name, " "));

$firtname = substr($name, 0, strpos($name, " "));
echo $firtname;
?>