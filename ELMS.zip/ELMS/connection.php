<?php
$conn = mysqli_connect("localhost", "root", "admin", "9am_elms_project");
if(!$conn) {
    die("Connection to database could not be established");
}
?>